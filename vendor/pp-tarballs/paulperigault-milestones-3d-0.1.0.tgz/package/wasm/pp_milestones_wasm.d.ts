/* tslint:disable */
/* eslint-disable */

export class Scene {
    free(): void;
    [Symbol.dispose](): void;
    activeId(): string | undefined;
    /**
     * Le contexte est perdu : ses ressources n'existent plus, rien à libérer.
     */
    contextLost(): void;
    /**
     * Le contexte est revenu : programme et tampons sont recréés.
     */
    contextRestored(): void;
    /**
     * Libère les ressources et rend le contexte au navigateur.
     */
    destroy(): void;
    /**
     * Dessine une image ; vrai si une autre image est due (transition ou inclinaison en cours).
     */
    frame(now: number): boolean;
    /**
     * # Errors
     * Code de la scène ou de WebGL (`gl-unavailable`, `shader-compile`, `program-link`…).
     */
    constructor(canvas: HTMLCanvasElement, ids: string[], statuses: string[], emblems: string[], goal: boolean, theme: Float32Array | number[], active: string);
    /**
     * Identifiant du jalon sous le point visé (coordonnées normalisées, y vers le haut).
     */
    pick(x: number, y: number, now: number): string | undefined;
    pointerLeave(): void;
    pointerMove(x: number, y: number): void;
    resize(width: number, height: number): void;
    setActive(id: string, now: number): void;
    /**
     * Inclinaison de l'appareil, normalisée ; des valeurs non finies rendent la main au pointeur.
     */
    setGyro(x: number, y: number): void;
    setTheme(theme: Float32Array | number[]): void;
}

/**
 * Valide les entrées sans toucher au canvas : même contrôle que `Scene::new`.
 *
 * # Errors
 * Code de la scène (`SceneError::code`) pour une donnée ou un thème invalide.
 */
export function checkInput(ids: string[], statuses: string[], emblems: string[], goal: boolean, theme: Float32Array | number[]): void;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly __wbg_scene_free: (a: number, b: number) => void;
    readonly checkInput: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number) => [number, number];
    readonly scene_activeId: (a: number) => [number, number];
    readonly scene_contextLost: (a: number) => void;
    readonly scene_contextRestored: (a: number) => [number, number];
    readonly scene_destroy: (a: number) => void;
    readonly scene_frame: (a: number, b: number) => [number, number, number];
    readonly scene_new: (a: any, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number, k: number, l: number) => [number, number, number];
    readonly scene_pick: (a: number, b: number, c: number, d: number) => [number, number];
    readonly scene_pointerLeave: (a: number) => void;
    readonly scene_pointerMove: (a: number, b: number, c: number) => void;
    readonly scene_resize: (a: number, b: number, c: number) => [number, number];
    readonly scene_setActive: (a: number, b: number, c: number, d: number) => [number, number];
    readonly scene_setGyro: (a: number, b: number, c: number) => void;
    readonly scene_setTheme: (a: number, b: number, c: number) => [number, number];
    readonly __wbindgen_malloc: (a: number, b: number) => number;
    readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
    readonly __wbindgen_free: (a: number, b: number, c: number) => void;
    readonly __externref_table_alloc: () => number;
    readonly __wbindgen_externrefs: WebAssembly.Table;
    readonly __wbindgen_exn_store: (a: number) => void;
    readonly __externref_drop_slice: (a: number, b: number) => void;
    readonly __externref_table_dealloc: (a: number) => void;
    readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
