/* tslint:disable */
/* eslint-disable */

export class Scene {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Le contexte est perdu : ses ressources n'existent plus, rien à libérer.
     */
    contextLost(): void;
    /**
     * Le contexte est revenu : programmes, tampons et textures (depuis les bitmaps conservés).
     */
    contextRestored(): void;
    /**
     * Libère les ressources, ferme les bitmaps et rend le contexte au navigateur.
     */
    destroy(): void;
    /**
     * Dessine une image ; vrai si une autre image est due (transition ou inclinaison en cours).
     * Toute commande (progression, survol, actif, texture, thème, taille) demande une image.
     */
    frame(now: number): boolean;
    /**
     * Une étape de l'initialisation du GPU : `0` terminé, `1` d'autres étapes suivent, `2` le GPU
     * compile encore. Sans effet une fois terminé. Aucune image n'est dessinée avant la fin.
     *
     * # Errors
     * Code de WebGL (`shader-compile`, `program-link`, `gl-resource`) ; les ressources déjà créées
     * sont libérées.
     */
    gpuStep(): number;
    /**
     * Vrai quand le GPU a rattrapé tout ce qui lui a été envoyé : la clôture est posée au premier
     * appel et interrogée ensuite, sans jamais bloquer. Un appel synchrone (redimensionnement du
     * canvas) attend sinon toute la file du GPU, tracé des tuiles de la page compris.
     */
    idle(): boolean;
    /**
     * # Errors
     * Code de la scène ou de WebGL (`gl-unavailable`) ; le GPU s'initialise ensuite par `gpuStep`.
     */
    constructor(canvas: HTMLCanvasElement, ids: string[], statuses: string[], badges: Uint8Array | number[], goal: boolean, theme: Float32Array | number[], active: string);
    /**
     * Identifiant de l'étape sous le point visé (coordonnées normalisées de -1 à 1, y vers le
     * haut), chaîne vide s'il n'y en a pas.
     */
    pick(x: number, y: number): string;
    pointerLeave(): void;
    pointerMove(x: number, y: number): void;
    /**
     * Progression d'une étape (jalon ou `@goal`), -1 si l'identifiant est inconnu.
     */
    progressOf(id: string): number;
    /**
     * Quatre nombres par étape, jalons puis objectif : x, y (de 0 à 1, origine en haut à gauche
     * du canvas), rayon de la médaille rapporté à la hauteur du canvas, visibilité (1 ou 0).
     */
    project(): Float32Array;
    resize(width: number, height: number): void;
    /**
     * Étape active (anneau d'accent) ; chaîne vide : aucune. Faux si l'identifiant est inconnu.
     */
    setActive(id: string): boolean;
    /**
     * Inclinaison de l'appareil, normalisée ; des valeurs non finies rendent la main au pointeur.
     */
    setGyro(x: number, y: number): void;
    /**
     * Étape survolée (anneau, inclinaison) ; chaîne vide ou inconnue : aucune.
     */
    setHover(id: string): void;
    /**
     * Progression de 0 (première étape) à 1 (dernière) ; appliquée à la prochaine image.
     */
    setProgress(progress: number): void;
    /**
     * Badge du jalon `id` : le bitmap est conservé (recréation après perte de contexte) et libéré
     * par `destroy()` ou au remplacement. Un identifiant inconnu, ou l'objectif, est refusé.
     *
     * # Errors
     * `unknown-id`, ou `gl-resource` si l'envoi au GPU échoue (le bitmap reste conservé).
     */
    setTexture(id: string, bitmap: ImageBitmap): void;
    setTheme(theme: Float32Array | number[]): void;
    /**
     * Trace une image d'essai et pose une clôture derrière. Sans effet tant que le GPU n'est pas prêt.
     *
     * # Errors
     * Code de WebGL si le tracé échoue.
     */
    warmFrame(now: number): void;
    /**
     * Vrai quand le GPU a fini l'image d'essai (ou qu'il n'y en a pas) ; ne bloque jamais.
     */
    warmed(): boolean;
}

/**
 * Valide les entrées sans toucher au canvas : même contrôle que `Scene::new`.
 *
 * # Errors
 * Code de la scène (`SceneError::code`) pour une donnée ou un thème invalide.
 */
export function checkInput(ids: string[], statuses: string[], badges: Uint8Array | number[], goal: boolean, theme: Float32Array | number[]): void;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly __wbg_scene_free: (a: number, b: number) => void;
    readonly checkInput: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number) => [number, number];
    readonly scene_contextLost: (a: number) => void;
    readonly scene_contextRestored: (a: number) => [number, number];
    readonly scene_destroy: (a: number) => void;
    readonly scene_frame: (a: number, b: number) => [number, number, number];
    readonly scene_gpuStep: (a: number) => [number, number, number];
    readonly scene_idle: (a: number) => number;
    readonly scene_new: (a: any, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number, k: number, l: number) => [number, number, number];
    readonly scene_pick: (a: number, b: number, c: number) => [number, number];
    readonly scene_pointerLeave: (a: number) => void;
    readonly scene_pointerMove: (a: number, b: number, c: number) => void;
    readonly scene_progressOf: (a: number, b: number, c: number) => number;
    readonly scene_project: (a: number) => [number, number];
    readonly scene_resize: (a: number, b: number, c: number) => [number, number];
    readonly scene_setActive: (a: number, b: number, c: number) => number;
    readonly scene_setGyro: (a: number, b: number, c: number) => void;
    readonly scene_setHover: (a: number, b: number, c: number) => void;
    readonly scene_setProgress: (a: number, b: number) => [number, number];
    readonly scene_setTexture: (a: number, b: number, c: number, d: any) => [number, number];
    readonly scene_setTheme: (a: number, b: number, c: number) => [number, number];
    readonly scene_warmFrame: (a: number, b: number) => [number, number];
    readonly scene_warmed: (a: number) => number;
    readonly __wbindgen_malloc: (a: number, b: number) => number;
    readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
    readonly __wbindgen_free: (a: number, b: number, c: number) => void;
    readonly __externref_table_alloc: () => number;
    readonly __wbindgen_externrefs: WebAssembly.Table;
    readonly __wbindgen_exn_store: (a: number) => void;
    readonly __externref_drop_slice: (a: number, b: number) => void;
    readonly __externref_table_dealloc: (a: number) => void;
    readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
