/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const __wbg_scene_free: (a: number, b: number) => void;
export const checkInput: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number) => [number, number];
export const scene_activeId: (a: number) => [number, number];
export const scene_contextLost: (a: number) => void;
export const scene_contextRestored: (a: number) => [number, number];
export const scene_destroy: (a: number) => void;
export const scene_frame: (a: number, b: number) => [number, number, number];
export const scene_new: (a: any, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number, k: number, l: number) => [number, number, number];
export const scene_pick: (a: number, b: number, c: number, d: number) => [number, number];
export const scene_pointerLeave: (a: number) => void;
export const scene_pointerMove: (a: number, b: number, c: number) => void;
export const scene_resize: (a: number, b: number, c: number) => [number, number];
export const scene_setActive: (a: number, b: number, c: number, d: number) => [number, number];
export const scene_setGyro: (a: number, b: number, c: number) => void;
export const scene_setTheme: (a: number, b: number, c: number) => [number, number];
export const __wbindgen_malloc: (a: number, b: number) => number;
export const __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
export const __wbindgen_free: (a: number, b: number, c: number) => void;
export const __externref_table_alloc: () => number;
export const __wbindgen_externrefs: WebAssembly.Table;
export const __wbindgen_exn_store: (a: number) => void;
export const __externref_drop_slice: (a: number, b: number) => void;
export const __externref_table_dealloc: (a: number) => void;
export const __wbindgen_start: () => void;
